export interface AIProfile {
  uid: string;
  name: string;
  role: string;
  goals: string[];
}
